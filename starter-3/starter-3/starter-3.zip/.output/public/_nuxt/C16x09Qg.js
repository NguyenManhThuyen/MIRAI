import"./DytUndq1.js";const r=""+new URL("cloud_left.BiQKwpm6.svg",import.meta.url).href,o=""+new URL("cloud_right.Uv0Wasnk.svg",import.meta.url).href;export{r as _,o as a};
